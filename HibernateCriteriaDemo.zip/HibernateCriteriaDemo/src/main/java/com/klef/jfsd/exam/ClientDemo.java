package com.klef.jfsd.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import java.util.List;

public class ClientDemo {
    public static void main(String[] args) {
        // Step 1: Create SessionFactory
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Customer.class)
                .buildSessionFactory();

        // Step 2: Create a Session
        Session session = factory.getCurrentSession();

        try {
            // Insert a new customer
            session.beginTransaction();
            Customer newCustomer = new Customer();
            newCustomer.setName("John Doe");
            newCustomer.setEmail("john.doe@example.com");
            newCustomer.setAge(30);
            newCustomer.setLocation("New York");
            session.save(newCustomer);
            session.getTransaction().commit();

            // Retrieve customers with Criteria API
            session = factory.getCurrentSession();
            session.beginTransaction();
            List<Customer> customers = session.createCriteria(Customer.class)
                    .add(Restrictions.gt("age", 25))
                    .list();
            for (Customer customer : customers) {
                System.out.println(customer.getName() + " - " + customer.getAge());
            }
            session.getTransaction().commit();
        } finally {
            factory.close();
        }
    }
}
